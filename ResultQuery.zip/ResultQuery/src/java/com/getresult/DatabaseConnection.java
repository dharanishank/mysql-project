/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.getresult;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author dharani-inc2025
 */
public class DatabaseConnection {
    
    public ResultSet getResult(String query) throws ClassNotFoundException, SQLException{
        String username="root";
        String password="";
        //database connection
        String url="jdbc:mysql://localhost/student_database";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connect=DriverManager.getConnection(url,username,password);
        
        Statement st=connect.createStatement();
        ResultSet result=st.executeQuery(query);
        return result;
        
    }
    
}
