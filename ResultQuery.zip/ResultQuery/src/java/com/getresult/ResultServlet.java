/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.getresult;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ResultServlet extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            
            String query=request.getParameter("query");
         
            String[] arrayQuery=query.split(" ");
            String checkString=arrayQuery[0].toLowerCase();
           
            if(checkString.equals("select")){
                
                DatabaseConnection connect=new DatabaseConnection();
                ResultSet result=connect.getResult(query);
                ResultSetMetaData resultsetmetadata=result.getMetaData();
                int column_count=resultsetmetadata.getColumnCount();
                
                String[] column_names=new String[column_count];
                int count=0;
                
                JSONArray j_array=new JSONArray();
                JSONObject jsonobj=new JSONObject();
                
                while(count<column_count){
                    
                    column_names[count]=resultsetmetadata.getColumnName(count+1);
                    jsonobj.put((count+1), column_names[count]);
                    count++;
                }
                j_array.add(jsonobj);
                
                
                
                while(result.next()){
                    
                    count=0;
                    JSONObject jsonobject=new JSONObject();
                    
                    while(count<column_count){
                        
                        
                        jsonobject.put(count+1, result.getString(column_names[count]));
                        
                        count++;
                    }
                    j_array.add(jsonobject);
                    
                }
                JSONObject obj=new JSONObject();
                obj.put("table",j_array);
                response.getWriter().write(j_array.toString());
               
            }
            else{
                out.println("Error");
            }
        }
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ResultServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
